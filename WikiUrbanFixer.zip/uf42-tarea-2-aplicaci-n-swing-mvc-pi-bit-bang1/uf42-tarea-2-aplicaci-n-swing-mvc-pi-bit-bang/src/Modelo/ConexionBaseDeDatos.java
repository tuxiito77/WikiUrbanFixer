package Modelo;

import java.sql.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class ConexionBaseDeDatos {

	// Atributos de la clase
	private static final String USUARIO = "SYSTEM";
	private static final String PWD = "pabloalex1905+++";
	private static final String URL = "jdbc:oracle:thin:@localhost:1521:XE";
	private static Connection conexion;

	static {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conexion = DriverManager.getConnection(URL, USUARIO, PWD);
			System.out.println("-> Conexión con ORACLE establecida");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver JDBC no encontrado");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Error al conectarse a la BD");
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Error general de Conexión");
			e.printStackTrace();
		}
	}

	public static Connection getConnection() {
		return conexion;
	}

	public void terminar() {
		try {
			if (conexion != null && !conexion.isClosed()) {
				conexion.close();
				System.out.println("Conexión cerrada");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static boolean verificarUsuario(String Nick, String Pwd) {
		String query = "SELECT COUNT(*) FROM PABLO.Usuario WHERE Nick = ? AND Pwd = ?";
		try (PreparedStatement pstmt = conexion.prepareStatement(query)) {
			pstmt.setString(1, Nick);
			pstmt.setString(2, Pwd);
			try (ResultSet rs = pstmt.executeQuery()) {
				if (rs.next() && rs.getInt(1) > 0) {
					System.out.println("Inicio de sesión exitoso");
					return true;
				} else {
					System.out.println("Nick o contraseña inválidos");
					return false;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public void estructuraTabla() {
		try {
			String query = "SELECT * FROM PABLO.USUARIO";
			Statement stmt = conexion.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			int numeroColumnas = rsmd.getColumnCount();
			for (int i = 1; i <= numeroColumnas; i++) {
				System.out.println(rsmd.getColumnName(i) + " - " + rsmd.getColumnTypeName(i));
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}

	public static int registrarUsuario(String nick, String nombre, String apellido, String cp, String pwd, String foto) {
		int resultado = 0;
		try {
			String query = "INSERT INTO PABLO.Usuario (usr, nombre, apellido, cp, pwd, foto) VALUES (?, ?, ?, ?, ?, ?)";
			PreparedStatement pstmt = conexion.prepareStatement(query);
			pstmt.setString(1, nick);
			pstmt.setString(2, apellido);
			pstmt.setString(3, nombre);
			pstmt.setString(4, cp);
			pstmt.setString(5, pwd);
			pstmt.setString(6, "foto1"); // Assuming 'foto' is a CLOB column with some default value
			resultado = pstmt.executeUpdate();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
		return resultado;
	}

	public static boolean verificarUsuarioExistente(String nickname) {
		return false;
	}

}
